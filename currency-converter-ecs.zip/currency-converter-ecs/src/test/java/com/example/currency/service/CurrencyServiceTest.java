package com.example.currency.service;

import com.example.currency.client.ExchangeRateClient;
import com.example.currency.entity.QueryLog;
import com.example.currency.repository.QueryLogRepository;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class CurrencyServiceTest {

    @Test
    void getLiveRate_fetchesAndPersists() {
        ExchangeRateClient client = mock(ExchangeRateClient.class);
        QueryLogRepository repo = mock(QueryLogRepository.class);
        when(client.getLiveRate("USD", "EUR")).thenReturn(new BigDecimal("0.93"));

        CurrencyService service = new CurrencyService(client, repo);
        var response = service.getLiveRate("usd", "eur");

        assertThat(response.rate()).isEqualByComparingTo("0.93");
        assertThat(response.from()).isEqualTo("USD");
        assertThat(response.to()).isEqualTo("EUR");

        ArgumentCaptor<QueryLog> captor = ArgumentCaptor.forClass(QueryLog.class);
        verify(repo, times(1)).save(captor.capture());
        QueryLog saved = captor.getValue();
        assertThat(saved.getSourceCurrency()).isEqualTo("USD");
        assertThat(saved.getTargetCurrency()).isEqualTo("EUR");
        assertThat(saved.getRate()).isEqualTo(new BigDecimal("0.93"));
    }
}
