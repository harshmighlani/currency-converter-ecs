package com.example.currency.config;

import com.example.currency.client.ExchangeRateClient;
import com.example.currency.di.AppComponent;
import com.example.currency.di.DaggerAppComponent;
import com.example.currency.repository.QueryLogRepository;
import com.example.currency.service.CurrencyService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class DaggerConfig {

    @Bean
    public AppComponent appComponent(WebClient exchangeWebClient,
                                     QueryLogRepository queryLogRepository) {
        return DaggerAppComponent.factory().create(exchangeWebClient, queryLogRepository);
    }

    @Bean
    @DependsOn("appComponent")
    public ExchangeRateClient exchangeRateClient(AppComponent component) {
        return component.exchangeRateClient();
    }

    @Bean
    @DependsOn("appComponent")
    public CurrencyService currencyService(AppComponent component) {
        return component.currencyService();
    }
}
