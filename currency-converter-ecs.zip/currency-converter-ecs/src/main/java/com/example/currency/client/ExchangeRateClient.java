package com.example.currency.client;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
public class ExchangeRateClient {

    private final WebClient exchangeWebClient;

    public BigDecimal getLiveRate(String from, String to) {
        try {
            Map<String, Object> payload = exchangeWebClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path("/convert")
                            .queryParam("from", from)
                            .queryParam("to", to)
                            .build())
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, resp -> {
                        log.error("Exchange API error: status={} reason={}", resp.statusCode(), resp);
                        return Mono.error(new IllegalStateException("Failed to fetch exchange rate: " + resp.statusCode()));
                    })
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .block();

            if (payload == null) {
                throw new IllegalStateException("Empty response from exchange API");
            }

            Object result = payload.get("result");
            if (result == null) {
                log.warn("No 'result' field in response: {}", payload);
                throw new IllegalStateException("Unexpected response from exchange API");
            }
            return new BigDecimal(String.valueOf(result));
        } catch (WebClientResponseException e) {
            log.error("Exchange API HTTP error: status={} body={}", e.getStatusCode(), e.getResponseBodyAsString());
            throw new IllegalStateException("Exchange API error: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("Exchange API call failed", e);
            throw new IllegalStateException("Exchange API call failed: " + e.getMessage(), e);
        }
    }
}
