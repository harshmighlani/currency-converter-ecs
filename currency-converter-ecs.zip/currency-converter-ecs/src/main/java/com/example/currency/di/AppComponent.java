package com.example.currency.di;

import com.example.currency.client.ExchangeRateClient;
import com.example.currency.repository.QueryLogRepository;
import com.example.currency.service.CurrencyService;
import dagger.BindsInstance;
import dagger.Component;
import org.springframework.web.reactive.function.client.WebClient;

import javax.inject.Singleton;

@Singleton
@Component(modules = {AppModule.class})
public interface AppComponent {

    CurrencyService currencyService();

    ExchangeRateClient exchangeRateClient();

    @dagger.Component.Factory
    interface Factory {
        AppComponent create(@BindsInstance WebClient exchangeWebClient,
                            @BindsInstance QueryLogRepository queryLogRepository);
    }
}
