package com.example.currency.repository;

import com.example.currency.entity.QueryLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface QueryLogRepository extends JpaRepository<QueryLog, UUID> {
}
