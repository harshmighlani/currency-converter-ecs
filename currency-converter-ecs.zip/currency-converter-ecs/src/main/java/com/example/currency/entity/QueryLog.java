package com.example.currency.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "query_logs")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryLog {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "query_path", nullable = false)
    private String queryPath;

    @Column(name = "source_currency", length = 8, nullable = false)
    private String sourceCurrency;

    @Column(name = "target_currency", length = 8, nullable = false)
    private String targetCurrency;

    @Column(name = "params", columnDefinition = "TEXT")
    private String paramsJson;

    @Column(name = "queried_at", nullable = false)
    private Instant queriedAt;

    @Column(name = "rate", precision = 38, scale = 18)
    private BigDecimal rate;

    @Lob
    @Column(name = "response_json")
    private String responseJson;
}
