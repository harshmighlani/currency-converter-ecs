package com.example.currency.service;

import com.example.currency.client.ExchangeRateClient;
import com.example.currency.entity.QueryLog;
import com.example.currency.model.RateResponse;
import com.example.currency.repository.QueryLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
public class CurrencyService {

    private final ExchangeRateClient exchangeRateClient;
    private final QueryLogRepository queryLogRepository;

    public RateResponse getLiveRate(String from, String to) {
        String fromUpper = from.toUpperCase();
        String toUpper = to.toUpperCase();
        log.info("Fetching live rate: {} -> {}", fromUpper, toUpper);

        BigDecimal rate = exchangeRateClient.getLiveRate(fromUpper, toUpper);
        RateResponse response = new RateResponse(fromUpper, toUpper, rate, Instant.now());

        // Persist audit log
        Map<String, Object> params = Map.of("from", fromUpper, "to", toUpper);
        QueryLog logEntry = QueryLog.builder()
                .queryPath("/api/rates")
                .sourceCurrency(fromUpper)
                .targetCurrency(toUpper)
                .paramsJson(params.toString())
                .queriedAt(Instant.now())
                .rate(rate)
                .responseJson(response.toString())
                .build();
        queryLogRepository.save(logEntry);

        return response;
    }
}
