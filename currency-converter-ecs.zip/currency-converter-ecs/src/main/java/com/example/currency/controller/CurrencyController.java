package com.example.currency.controller;

import com.example.currency.model.RateResponse;
import com.example.currency.service.CurrencyService;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Validated
public class CurrencyController {

    private final CurrencyService currencyService;

    @GetMapping("/rates")
    public RateResponse getRate(@RequestParam("from") @NotBlank String from,
                                @RequestParam("to") @NotBlank String to) {
        return currencyService.getLiveRate(from, to);
    }
}
