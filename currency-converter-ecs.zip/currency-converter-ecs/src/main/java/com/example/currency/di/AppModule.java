package com.example.currency.di;

import com.example.currency.client.ExchangeRateClient;
import com.example.currency.repository.QueryLogRepository;
import com.example.currency.service.CurrencyService;
import dagger.Module;
import dagger.Provides;
import org.springframework.web.reactive.function.client.WebClient;

import javax.inject.Singleton;

@Module
public class AppModule {

    @Provides
    @Singleton
    public ExchangeRateClient provideExchangeRateClient(WebClient exchangeWebClient) {
        return new ExchangeRateClient(exchangeWebClient);
    }

    @Provides
    @Singleton
    public CurrencyService provideCurrencyService(ExchangeRateClient exchangeRateClient,
                                                  QueryLogRepository queryLogRepository) {
        return new CurrencyService(exchangeRateClient, queryLogRepository);
    }
}
