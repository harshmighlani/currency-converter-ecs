# Currency Converter ECS-ready Spring Boot Skeleton

A minimal Spring Boot application prepared for containerization on AWS ECS. It exposes an endpoint to fetch live currency conversion rates and logs every request/response into a local PostgreSQL database.

## Features
- Spring Boot 3, Java 17, Gradle build
- REST endpoint: `GET /api/rates?from=USD&to=EUR`
- External API: exchangerate.host (free, no API key)
- Persistence: Spring Data JPA + PostgreSQL
- Structured logging with Logback (console + rolling file)
- JUnit 5 tests (service + controller)
- Dockerfile for containerization
- docker-compose for local PostgreSQL

## Running locally
1. Start Postgres:
   ```bash
   docker compose up -d
   ```
2. Build and run the app:
   ```bash
   ./gradlew bootRun
   ```
3. Call the endpoint:
   ```bash
   curl "http://localhost:8080/api/rates?from=USD&to=EUR"
   ```

## Docker
Build image using the provided Dockerfile (multi-stage):
```bash
docker build -t currency-converter-ecs:latest .
```
Run the container (expect the DB to be reachable at host.docker.internal or link with compose network):
```bash
docker run --rm -p 8080:8080 \
  -e SPRING_DATASOURCE_URL=jdbc:postgresql://host.docker.internal:5432/currency_db \
  -e SPRING_DATASOURCE_USERNAME=postgres \
  -e SPRING_DATASOURCE_PASSWORD=postgres \
  currency-converter-ecs:latest
```

## AWS ECS notes
- Push the built image to ECR.
- Create an ECS Task Definition using that image, set container port 8080.
- Provide the DB connection via environment variables or AWS Secrets Manager.
- Configure health checks on `/actuator/health` (add actuator if desired).

## Configuration
- `src/main/resources/application.yml` contains defaults for local development.
- Override with env vars when running in containers (e.g., `SPRING_DATASOURCE_URL`).

## Database log table
`query_logs` captures:
- query_path
- source_currency
- target_currency
- params (as text)
- queried_at (timestamp)
- rate (numeric)
- response_json (text)

## Project layout
- `com.example.currency.controller.CurrencyController`
- `com.example.currency.service.CurrencyService`
- `com.example.currency.client.ExchangeRateClient`
- `com.example.currency.entity.QueryLog`
- `com.example.currency.repository.QueryLogRepository`

## Testing
```bash
./gradlew test
```
